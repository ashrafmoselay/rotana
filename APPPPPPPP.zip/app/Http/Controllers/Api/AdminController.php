<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Support\Access;
use App\Support\Audit;
use App\Support\UiText;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Validation\Rule;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Role;
use Yajra\DataTables\Facades\DataTables;

class AdminController extends Controller
{
    public function maintenance()
    {
        abort_unless(auth()->user()->hasRole('admin'), 403);

        // A filesystem lock survives cache:clear and prevents overlapping runs.
        $lock = fopen(storage_path('app/maintenance.lock'), 'c');
        abort_unless($lock, 500, 'تعذر بدء صيانة النظام.');
        if (! flock($lock, LOCK_EX | LOCK_NB)) {
            fclose($lock);
            abort(409, 'توجد عملية صيانة قيد التنفيذ.');
        }

        $results = [];
        try {
            foreach ([
                'migrate' => ['تحديث قاعدة البيانات', ['--force' => true]],
                'cache:clear' => ['مسح كاش التطبيق', []],
                'config:clear' => ['مسح كاش الإعدادات', []],
                'route:clear' => ['مسح كاش المسارات', []],
                'view:clear' => ['مسح كاش القوالب', []],
            ] as $command => [$label, $options]) {
                try {
                    $success = Artisan::call($command, $options) === 0;
                } catch (\Throwable $e) {
                    report($e);
                    $success = false;
                }
                $results[] = ['label' => $label, 'success' => $success];
                if (! $success) {
                    break;
                }
            }

            if (! in_array(false, array_column($results, 'success'), true)) {
                $path = public_path('storage');
                try {
                    if (! file_exists($path) && ! is_link($path)) {
                        File::link(storage_path('app/public'), $path);
                    }
                    $success = is_link($path) && is_dir($path) && realpath($path) === realpath(storage_path('app/public'));
                } catch (\Throwable $e) {
                    report($e);
                    $success = false;
                }
                $results[] = ['label' => 'رابط storage في public', 'success' => $success];
            }
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }

        $success = ! in_array(false, array_column($results, 'success'), true);

        return response()->json([
            'message' => $success ? 'تمت صيانة النظام بنجاح.' : 'توقفت الصيانة عند خطوة غير ناجحة. راجع النتائج؛ الخطوات السابقة قد تم تنفيذها.',
            'results' => $results,
        ], $success ? 200 : 500);
    }

    public function users(Request $r)
    {
        Access::allow('users.manage');
        $this->clampDataTableLength($r);

        $q = User::query()->select('id', 'name', 'email', 'active', 'all_branches')->with('roles:id,name', 'branches:id,name');
        if (! auth()->user()->all_branches) {
            $q->where('all_branches', false)
                ->whereHas('branches', fn ($q) => $q->whereIn('branches.id', auth()->user()->branches()->select('branches.id')));
        }

        return DataTables::eloquent($q)->escapeColumns([])->toJson();
    }

    public function userSave(Request $r, ?User $user = null)
    {
        Access::allow('users.manage');
        $user ??= new User;
        $d = $r->validate(['name' => 'required|string|max:190', 'email' => ['required', 'email', 'max:190', Rule::unique('users')->ignore($user->id)], 'password' => [$user->exists ? 'nullable' : 'required', 'string', 'min:12', 'max:128'], 'active' => 'required|boolean', 'all_branches' => 'required|boolean', 'roles' => 'required|array|min:1', 'roles.*' => 'required|exists:roles,name', 'branch_ids' => 'present|array', 'branch_ids.*' => 'integer|distinct|exists:branches,id']);
        abort_unless($d['all_branches'] || count($d['branch_ids']) > 0, 422, 'اختر فرعًا واحدًا على الأقل.');

        return DB::transaction(function () use ($user, $d) {
            $adminRole = Role::where('name', 'admin')->lockForUpdate()->firstOrFail();
            if ($user->exists) {
                $user = User::lockForUpdate()->findOrFail($user->id);
                if ($user->hasRole('admin') && (! $d['active'] || ! in_array('admin', $d['roles']) || ! $d['all_branches'])) {
                    abort_if(User::role('admin')->where('active', true)->where('id', '!=', $user->id)->count() === 0, 422, 'لا يمكن تعطيل آخر مدير نظام أو إزالة صلاحياته.');
                }
            }
            if ($user->id === auth()->id()) {
                abort_unless($d['active'] && in_array('admin', $d['roles']) && $d['all_branches'], 422, 'لا يمكنك إزالة صلاحيات إدارة حسابك الحالي.');
            }
            $values = collect($d)->only('name', 'email', 'active', 'all_branches')->all();
            if (! empty($d['password'])) {
                $values['password'] = $d['password'];
            }
            $user->fill($values)->save();
            $user->syncRoles($d['roles']);
            $user->branches()->sync($d['branch_ids']);
            Audit::record('users.saved', $user, ['roles' => $d['roles'], 'active' => $d['active'], 'all_branches' => $d['all_branches'], 'branch_ids' => $d['branch_ids']]);

            return $user->load('roles', 'branches');
        });
    }

    public function roles()
    {
        abort_unless(auth()->user()->can('roles.manage') || auth()->user()->can('users.manage'), 403);

        return [
            'roles' => Role::with('permissions:id,name')->get(),
            'permissions' => config('rotana.permissions'),
            'permission_groups' => UiText::permissionGroups(),
            'permission_catalog' => UiText::permissionCatalog(),
            'role_labels' => UiText::roleLabels(),
        ];
    }

    public function roleSave(Request $r, ?Role $role = null)
    {
        Access::allow('roles.manage');
        $role ??= new Role;
        $d = $r->validate(['name' => ['required', 'string', 'max:100', Rule::unique('roles')->ignore($role->id)], 'permissions' => 'present|array', 'permissions.*' => ['string', Rule::in(config('rotana.permissions'))]]);
        abort_if($role->exists && $role->name === 'admin', 422, 'دور مدير النظام محمي. أنشئ دورًا مخصصًا بدلًا منه.');

        return DB::transaction(function () use ($role, $d) {
            $role->fill(['name' => $d['name'], 'guard_name' => 'web'])->save();
            $role->syncPermissions($d['permissions']);
            Audit::record('roles.saved', $role, ['permissions' => $d['permissions']]);

            return $role->load('permissions');
        });
    }

    public function activity(Request $r)
    {
        Access::allow('activity.view');
        $this->clampDataTableLength($r);
        $q = Activity::with('causer:id,name', 'subject')->latest('id');
        if (! auth()->user()->all_branches) {
            $q->whereIn('properties->branch_id', auth()->user()->branches()->pluck('branches.id'));
        }

        return DataTables::eloquent($q)
            ->addColumn('event_label', fn (Activity $activity) => UiText::activityEventLabel($activity->event))
            ->addColumn('subject_label', fn (Activity $activity) => UiText::subjectLabel($activity->subject_type))
            ->addColumn('subject_reference', fn (Activity $activity) => UiText::subjectReference($activity))
            ->addColumn('details', fn (Activity $activity) => UiText::activityDetails($activity))
            ->removeColumn('properties')
            ->removeColumn('subject')
            ->escapeColumns([])
            ->toJson();
    }

    private function clampDataTableLength(Request $r): void
    {
        if ($r->has('length')) {
            $r->merge(['length' => min(max((int) $r->input('length'), 1), 100)]);
        }
    }
}
